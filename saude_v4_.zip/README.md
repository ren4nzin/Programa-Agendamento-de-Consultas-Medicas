Saúde V3 - Moderna Azul (React + Vite)

Run backend:
- cd backend
- copy .env.example to .env and set MONGO_URI or run local MongoDB
- npm install
- npm run dev

Frontend:
- cd frontend
- npm install
- npm run dev
- Open http://localhost:5173

API base is http://localhost:4000/api
